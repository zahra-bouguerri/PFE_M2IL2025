package routines;

public class MyUtils {

    public static java.util.Date parseMonthYear(String monthYearStr) throws java.text.ParseException {
        // Mapping months in English
        java.util.Map<String, String> months = new java.util.HashMap<>();
        months.put("january", "01");
        months.put("february", "02");
        months.put("march", "03");
        months.put("april", "04");
        months.put("may", "05");
        months.put("june", "06");
        months.put("july", "07");
        months.put("august", "08");
        months.put("september", "09");
        months.put("october", "10");
        months.put("november", "11");
        months.put("december", "12");

        // Split the input string into month and year parts
        String[] parts = monthYearStr.split("_");
        String monthStr = parts[0].toLowerCase();  // Convert month to lowercase
        String year = parts[1];

        // Get the month number from the map
        String monthNum = months.get(monthStr);

        // Construct the date string in MM/dd/yyyy format (we use the 1st of the month)
        String dateStr = monthNum + "/01/" + year;

        // Parse the date string and return the Date object
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
        return sdf.parse(dateStr);
    }
}
